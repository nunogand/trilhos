---
layout: default
title: Sobre
permalink: /sobre/
---
<header class="page-hero"><div class="hero-content"><div class="eyebrow">O projeto</div><h1>Sobre Trilhos</h1><p>Um espaço para documentar percursos pedestres com mapas e fotografia.</p></div></header>
<section><div class="container prose"><h2>Uma demonstração pronta a personalizar</h2><p>Este projeto reúne relatos, imagens locais e ficheiros GPX numa publicação estática. Para adicionar um percurso, crie uma pasta em <code>assets/media/</code> e um ficheiro Markdown em <code>_posts/</code>.</p></div></section>
