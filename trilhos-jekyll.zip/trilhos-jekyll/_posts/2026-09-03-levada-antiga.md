---
title: "Levada Antiga"
description: "Caminho tranquilo junto a uma antiga levada."
tags: [água, família]
---

## Sobre o percurso

Caminho tranquilo junto a uma antiga levada. Este é conteúdo de demonstração, criado para mostrar a estrutura editorial do site. Substitua-o pelas informações reais do percurso, indicações de acesso, segurança e pontos de interesse.

## Recomendações

Leve água, calçado adequado e consulte as condições locais antes de iniciar o percurso.
