---
title: "Cume do Vento"
description: "Um percurso exposto com horizontes amplos."
tags: [montanha, exigente]
---

## Sobre o percurso

Um percurso exposto com horizontes amplos. Este é conteúdo de demonstração, criado para mostrar a estrutura editorial do site. Substitua-o pelas informações reais do percurso, indicações de acesso, segurança e pontos de interesse.

## Recomendações

Leve água, calçado adequado e consulte as condições locais antes de iniciar o percurso.
