---
title: "Rota dos Moinhos"
description: "Caminho cultural entre moinhos e campos."
tags: [património, família]
---

## Sobre o percurso

Caminho cultural entre moinhos e campos. Este é conteúdo de demonstração, criado para mostrar a estrutura editorial do site. Substitua-o pelas informações reais do percurso, indicações de acesso, segurança e pontos de interesse.

## Recomendações

Leve água, calçado adequado e consulte as condições locais antes de iniciar o percurso.
