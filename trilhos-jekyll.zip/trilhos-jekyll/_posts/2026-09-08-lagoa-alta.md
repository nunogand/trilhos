---
title: "Lagoa Alta"
description: "Percurso de altitude até uma lagoa serena."
tags: [montanha, água]
---

## Sobre o percurso

Percurso de altitude até uma lagoa serena. Este é conteúdo de demonstração, criado para mostrar a estrutura editorial do site. Substitua-o pelas informações reais do percurso, indicações de acesso, segurança e pontos de interesse.

## Recomendações

Leve água, calçado adequado e consulte as condições locais antes de iniciar o percurso.
