---
title: "Carvalhal Secreto"
description: "Trilho sombreado em floresta autóctone."
tags: [floresta, circular]
---

## Sobre o percurso

Trilho sombreado em floresta autóctone. Este é conteúdo de demonstração, criado para mostrar a estrutura editorial do site. Substitua-o pelas informações reais do percurso, indicações de acesso, segurança e pontos de interesse.

## Recomendações

Leve água, calçado adequado e consulte as condições locais antes de iniciar o percurso.
