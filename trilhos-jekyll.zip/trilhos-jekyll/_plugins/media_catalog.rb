# frozen_string_literal: true
require "set"
module Trilhos
  IMAGE_EXTENSIONS = Set.new(%w[.jpg .jpeg .png .webp .avif])
  class MediaCatalog < Jekyll::Generator
    safe true
    priority :highest
    def generate(site)
      site.posts.docs.each do |post|
        folder = (post.data["media_folder"] || post.data["slug"] || post.basename_without_ext.sub(/^\d{4}-\d{2}-\d{2}-/, "")).to_s
        prefix = "/assets/media/#{folder}/"
        files = site.static_files.select { |f| f.path.start_with?(prefix) }
        images = files.select { |f| IMAGE_EXTENSIONS.include?(f.extname.downcase) }.sort_by(&:path).map(&:path)
        gpx = files.select { |f| f.extname.downcase == ".gpx" }.sort_by(&:path).first
        post.data["media_folder"] = folder
        post.data["media_images"] = images
        post.data["gpx_path"] = gpx&.path
        post.data["cover_image"] = images.sample unless images.empty?
        Jekyll.logger.warn("Trilhos:", "Sem GPX em #{prefix}") unless gpx
        Jekyll.logger.warn("Trilhos:", "Sem imagens em #{prefix}") if images.empty?
      end
    end
  end
  class TagPage < Jekyll::Page
    def initialize(site, base, tag, posts)
      @site, @base, @dir, @name = site, base, File.join("tags", Jekyll::Utils.slugify(tag)), "index.html"
      process(@name)
      read_yaml(File.join(base, "_layouts"), "tag.html")
      data["tag"] = tag; data["title"] = "Percursos: #{tag}"; data["posts"] = posts
    end
  end
  class TagGenerator < Jekyll::Generator
    safe true
    def generate(site)
      site.tags.each { |tag, posts| site.pages << TagPage.new(site, site.source, tag, posts) }
    end
  end
end
