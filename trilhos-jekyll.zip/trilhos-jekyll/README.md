# Trilhos

Site Jekyll demonstrativo com catálogo automático de imagens e GPX por publicação.

## Executar

```bash
bundle install
bundle exec jekyll serve
```

Abra `http://localhost:4000`.

## Adicionar um percurso

1. Crie `assets/media/meu-percurso/`.
2. Adicione imagens `.jpg`, `.jpeg`, `.png`, `.webp` ou `.avif` e um ficheiro `.gpx`.
3. Crie `_posts/AAAA-MM-DD-meu-percurso.md`.
4. Se a pasta não coincidir com o slug, adicione `media_folder: nome-da-pasta` ao front matter.

O plugin `_plugins/media_catalog.rb` ordena as imagens alfabeticamente, seleciona uma capa aleatória em cada build e usa o primeiro GPX por ordem alfabética. As tags geram páginas em `/tags/<tag>/`.

## Build para alojamento estático

```bash
JEKYLL_ENV=production bundle exec jekyll build
```

Publique o conteúdo da pasta `_site` no seu alojamento.
